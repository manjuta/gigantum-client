## Your First Gigantum Project
Welcome to your first Gigantum Project. **If you want to jump right in, simply click the "Launch Jupyterlab" button in the top right corner!**

The Gigantum Client is a tool you can run locally on your laptop or on a remote server. It provides an interface to create, view, modify and share Projects and Datasets. A Gigantum Project is an integrated repository that bundles together code, data, environment configuration, and work history automatically. It is the physical representation on your hard drive of your data science work that can easily be shared with others. A Dataset is similar to a Project, but is only responsible for managing data files. Datasets provide additional benefits such as the ability to handle large data, deduplicate data, and partially download data. Your Gigantum account comes with free storage that can be used to share and backup your work by syncing with Gigantum Cloud.

## What If I Need Help?
Clicking on the question mark in the bottom right corner gives access to a guide, docs, and feedback.

Documentation on how to use the Gigantum Client can be found at [https://docs.gigantum.com/](https://docs.gigantum.com).

If you have questions or problems, you can join our Spectrum Chat here: [https://spectrum.chat/gigantum](https://spectrum.chat/gigantum)

Finally, you can always reach us at support@gigantum.com

## Licenses
The file `income_per_person_gdppercapita_ppp_inflation_adjusted.xlsx` comes from [https://www.gapminder.org/](https://www.gapminder.org/) and is provided with the Creative Commons Attribution 3.0 Unported license.

The Stack Overflow Developer Survey 2018 data is provided by Stack Overflow at [https://insights.stackoverflow.com/survey/2018/](https://insights.stackoverflow.com/survey/2018/) with the Open Database License (ODbL).

The remaining files in this project and the included code is MIT licensed.
