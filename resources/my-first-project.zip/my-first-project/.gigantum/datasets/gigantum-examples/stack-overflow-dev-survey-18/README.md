## Stack Overflow Developer Survey 2018 Results
Data downloaded from [https://insights.stackoverflow.com/survey/2018/](https://insights.stackoverflow.com/survey/2018/)

"Each year, we ask the developer community about everything from their favorite technologies to their job preferences. This year marks the eighth year we’ve published our Annual Developer Survey results—with the largest number of respondents yet. Over 100,000 developers took the 30-minute survey this past January."

## License
Contents of this Dataset are provided by Stack Overflow with the [Open Database License (ODbL)](https://opendatacommons.org/licenses/odbl/1.0/)