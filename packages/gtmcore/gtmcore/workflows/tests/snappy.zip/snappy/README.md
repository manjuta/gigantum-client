__code/tutorial.ipynb__ reproduces the Snap.Py tutorial (https://snap.stanford.edu/snappy/doc/tutorial/tutorial.html) for interactive use.

__code/graphwave/Using Graphwave.ipynb__ contains the GraphWave notebook demo of the SNAP GraphWave package http://snap.stanford.edu/graphwave/. 